import Characters.BasicCharacter;
import Player.Player;

public class Main {
    public static void main(String[] args) {

        BasicCharacter basicCharacter = new BasicCharacter("Ejemplo", 100, 50);
        //Aquí estaban llamando a la clase no al objeto
        basicCharacter.displayData();

        //Aquí hacia falta pasar el nombre del Jugador o Solicitarlo
        Player P1 = new Player("Nombre");
        P1.displayData();
        P1.attack(basicCharacter);
        P1.defend();
        P1.displayData();

    }
}