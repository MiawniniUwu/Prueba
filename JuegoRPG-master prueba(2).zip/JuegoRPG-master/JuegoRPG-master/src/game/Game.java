package game;

import Enemies.Enemy;
import Enemies.Kitsunes.KitsuneExperimentado;
import Enemies.Kitsunes.KitsuneLadron;
import Enemies.Kitsunes.KitsuneSorcerer;
import game.exceptions.EnemyDeadException;
import game.exceptions.InvalidOptionException;
import game.exceptions.PlayerDeathException;
import util.FileManager;
import util.Interactive;
import util.Randomized;
import Player.Player;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Game {
    private Player player;
    private final List<Enemy> enemies;

    public Game(){
        player = null;
        enemies = new ArrayList<>(5);
        enemies.add(new KitsuneLadron());
        enemies.add(new KitsuneExperimentado());
        enemies.add(new KitsuneSorcerer());
        enemies.add(new KitsuneLadron());
        enemies.add(new KitsuneExperimentado());
    }
    public void printMainMenu() {

        String menu = "1. Jugar\n2. Salir";
        try {
            int option = Integer.parseInt(JOptionPane.showInputDialog(menu));
            switch (option) {

                case 1 -> {
                    try {
                        player = FileManager.loadGame();
                        Interactive.printDialog("¡Bienvenido de nuevo!");
                    } catch (Exception e) {
                        player = new Player(JOptionPane.showInputDialog("Ingresa el nombre del jugador:"));
                    }
                    printPlayerMenu();
                }
                case 2 -> Interactive.printDialog("Gracias por jugar");
                default -> throw new InvalidOptionException();
            }
        } catch (Exception e) {
            Interactive.printDialog("La opción ingresada no es válida");
            printMainMenu();
        }
    }
    private void printPlayerMenu() {

        String menu = """
				1. Ver estadísticas
				2. Ver inventario
				""";
        if (!enemies.isEmpty()) menu += String.format("3. Atacar [%d/5 Enemigos]\n", enemies.size());
        menu += """
				4. Equipar arma
				5. Equipar armadura
				6. Salir""";
        try {

            int option = Integer.parseInt(JOptionPane.showInputDialog(menu));
            switch (option) {

                case 1 -> player.displayData();
                case 2 -> player.getInventory().printItems();
                case 3 -> attackCycle();
                case 4 -> equipWeaponMenu();
                case 5 -> equipArmorMenu();
                case 6 -> endGame();
                default -> throw new InvalidOptionException();
            }
            if (option < 6) {

                printPlayerMenu();
            }
        } catch (Exception e) {
            Interactive.printDialog("La opción ingresada no es válida");
            printPlayerMenu();
        }
    }

    private void endGame() {

        Interactive.printDialog("Gracias por jugar");
        FileManager.saveGame(player);
        enemies.clear();
    }

    private void attackCycle() {

        Enemy currentEnemy;
        currentEnemy = getEnemy(enemies);
        while (!currentEnemy.isDead() && !player.isDead()) {

            battleMenu(currentEnemy);
        }
        enemies.remove(currentEnemy);
    }

    private void equipArmorMenu() {

        player.getInventory().equipArmorMenu(player);
    }

    private void equipWeaponMenu() {

        player.getInventory().equipWeaponMenu(player);
    }

    private void battleMenu(Enemy enemy) {

        String menu = "1. Atacar\n2. Huir";
        if (!enemy.isDead()) {
            try {

                int battleOption = Integer.parseInt(JOptionPane.showInputDialog(menu));
                switch (battleOption) {

                    case 1 -> battleOrder(enemy);
                    case 2 -> fleeTry(enemy);
                    default -> throw new InvalidOptionException();
                }
            } catch (InvalidOptionException e) {

                Interactive.printDialog("La opción ingresada no es válida");
                battleMenu(enemy);
            } catch (PlayerDeathException e) {

                gameOver();
            } catch (EnemyDeadException e) {

                Interactive.printDialog("El enemigo ha muerto!");
                enemy.setHealth(0);
            }
        }
    }

    private void gameOver() {

        Interactive.printDialog("Has muerto!");
        Interactive.printDialog("Quizás deberías entrenar más antes de intentar pelear con los enemigos.");
        player.revive();
        enemies.clear();
    }

    private void battleOrder(Enemy enemy) throws PlayerDeathException, EnemyDeadException {

        player.attack(enemy);
        if (!enemy.isDead()) {
            enemy.attack(player);
        }
        battleMenu(enemy);
    }

    private void fleeTry(Enemy enemy) {

        if (Randomized.randomizeBoolean()) {
            player.printRun();
            enemy.setHealth(0);
        } else {
            Interactive.printDialog("No has podido huir!");
            battleMenu(enemy);
        }
    }

    @NotNull
    private static Enemy getEnemy(List<Enemy> enemies) {

        Enemy enemy = enemies.get(Randomized.randomizeNumber(0, enemies.size() - 1));
        Interactive.printDialog(String.format("Un %s aparece!", enemy.getName()));
        return enemy;
    }

}
