package Items.Weapons;

import Items.Item;

import java.io.Serializable;

public abstract class Weapon extends Item implements Serializable {
    protected int atk;

    public Weapon(String name, String description, int price, int atk) {

        super(name, description, price);
        this.atk = atk;
    }
    protected String name;
    protected int attack;
    protected int price;
    protected String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}