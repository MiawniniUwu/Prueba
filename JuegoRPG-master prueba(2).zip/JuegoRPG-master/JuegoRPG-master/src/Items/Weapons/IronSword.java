package Items.Weapons;

import Items.Weapons.Weapon;

public class IronSword extends Weapon {
    private int durability;
    private String rarity;

    public IronSword(String name, int attack, int price, String description) {
        super(name, attack, price, description);
        this.durability = durability;
        this.rarity = rarity;
    }

    public int getDurability() {
        return durability;
    }

    public void setDurability(int durability) {
        this.durability = durability;
    }

    public String getRarity() {
        return rarity;
    }

    public void setRarity(String rarity) {
        this.rarity = rarity;
    }
}
