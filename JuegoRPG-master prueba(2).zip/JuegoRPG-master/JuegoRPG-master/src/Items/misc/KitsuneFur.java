package Items.misc;

import Items.Item;

import java.io.Serializable;

public class KitsuneFur extends Item implements Serializable {
    public KitsuneFur(){
        super("Piel de Kitsune", "La Piel de Kitsune es un objeto preciado, extraído con gran cuidado de las míticas criaturas conocidas como kitsunes. Estos zorros mágicos, venerados en la mitología japonesa, se cree que poseen una piel imbuida con energía espiritual y poderes sobrenaturales.",
                7);
    }
}
