package Items.misc;

import Items.Item;

import java.io.Serializable;

public class KitsuneEye extends Item implements Serializable {
    public KitsuneEye(){
        super("Ojo de Kitsune", "Este ojo centelleante, que irradia una energía mística, ha sido codiciado por generaciones debido a su capacidad para otorgar poderes sobrenaturales a aquellos que lo poseen.",
                10);
    }
}
