package Items.misc;

import Items.Item;

import java.io.Serializable;

public class KitsuneClaw extends Item implements Serializable {
    public KitsuneClaw (){
        super("Garra de Kitsune", "Un objeto poderoso que otorga habilidades sobrenaturales relacionadas con la astucia, la agilidad y a menudo la manipulación.",
                5);
    }

}
