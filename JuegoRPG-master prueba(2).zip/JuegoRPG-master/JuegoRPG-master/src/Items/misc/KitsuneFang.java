package Items.misc;

import Items.Item;

import java.io.Serializable;

public class KitsuneFang extends Item implements Serializable {
    public KitsuneFang(){
        super("Colmillo de Kitsune", "Este colmillo afilado, envuelto en una luminosa energía espiritual, es codiciado por su capacidad para otorgar habilidades sobrenaturales a quienes lo poseen.",
                15);
    }
}
