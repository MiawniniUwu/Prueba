package Enemies.Kitsunes;

import Enemies.Enemy;
import Items.misc.KitsuneClaw;
import Items.misc.KitsuneEye;
import Player.Player;
import game.exceptions.EnemyDeadException;
import util.Randomized;

import static util.Randomized.randomizeNumber;

public class KitsuneExperimentado extends Enemy {

    public KitsuneExperimentado() {
        super("Kitsune Experimentado", 8, 4, 4, 4);
    }

    @Override
    public void attack(Player Player) throws EnemyDeadException {
        if (!isDead()) {

            double simpleAttackProbability = 0.5;
            double screechProbability = 0.5;
            double totalProbability = simpleAttackProbability + screechProbability;
            double ratio = Randomized.randomizeDouble(totalProbability);
            // simpleAttackProbability = 50%, screechProbability = 50%
            // simpleAttackProbability + screechProbability = 100%
            // ratio = 0.0 - 0.5 -> simpleAttack, ratio = 0.51 - 1.0 -> screech
            if (ratio <= simpleAttackProbability) simpleAttack(player);
            else screech(player);
        } else {
            throw new EnemyDeadException();
        }
    }

    @Override
    public void dropItem(Player player) {

        int ratio = Randomized.randomizeNumber(1, 100);
        player.getInventory().addItem(ratio > 50 ? new KitsuneEye() : new KitsuneClaw());
    }

    public void simpleAttack(Player player) {

        Interactive.printDialog(String.format("¡%s ataca con %d puntos de daño!", getName(), getDamage()));
        player.takeDamage(getDamage());
    }

    public void screech(Player player) {

        Interactive.printDialog(String.format("¡El Kitsune Experimentado emite un sonido aterrador que causa %d de " +
                "daño!", getDamage() * 2));
        player.takeDamage(getDamage() * 2);
    }
}
