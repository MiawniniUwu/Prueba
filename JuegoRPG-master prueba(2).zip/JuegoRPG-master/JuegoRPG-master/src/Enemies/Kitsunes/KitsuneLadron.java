package Enemies.Kitsunes;

import Enemies.Enemy;
import Items.Armors.LeatherHelmet;
import Items.misc.KitsuneFur;
import Player.Player;
import game.exceptions.EnemyDeadException;
import util.Randomized;

import static util.Randomized.randomizeNumber;

public class KitsuneLadron extends Enemy {
    public KitsuneLadron() {
        super("Kitsune Ladrón", 30, 5, 10, 10);
    }

    @Override
    public void attack(Player player) throws EnemyDeadException {
        if (!isDead()) {

            double simpleAttackProbability = 0.5;
            double howlProbability = 0.3;
            double biteProbability = 0.2;
            double totalProbability = simpleAttackProbability + howlProbability + biteProbability;
            double ratio = Randomized.randomizeDouble(totalProbability);
            // simpleAttackProbability = 50%, howlProbability = 30%, biteProbability = 20%
            // simpleAttackProbability + howlProbability + biteProbability = 100%
            // ratio = 0.0 - 0.5 -> simpleAttack, ratio = 0.51 - 0.7 -> bite, ratio = 0.71 - 1.0 -> howl
            if (ratio <= simpleAttackProbability) simpleAttack(player);
            else if (ratio <= simpleAttackProbability + biteProbability) bite(player);
            else howl(player);
        } else {
            throw new EnemyDeadException();
        }
    }

    @Override
    public void dropItem(Player player) {

        int ratio = Randomized.randomizeNumber(1, 100);
        player.getInventory().addItem(ratio > 65 ? new LeatherHelmet() : new KitsuneFur());
    }

    public void simpleAttack(Player player) {

        Interactive.printDialog(String.format("¡%s ataca con %d puntos de daño!", getName(), getDamage()));
        player.takeDamage(getDamage());
    }

    public void howl(Player player) {

        Interactive.printDialog("¡Kitsune Ladron se rie de ti JIJIJIJA!");
        //TODO: Implementar efecto de aullido.
    }

    public void bite(Player player) {

        int totalDamage = getDamage() + 3;
        Interactive.printDialog(String.format("¡%s muerde con %d puntos de daño!", getName(), totalDamage));
        player.takeDamage(totalDamage);
    }
}