package Enemies.Kitsunes;

import Enemies.Enemy;
import Items.Weapons.WoodenSword;
import Items.misc.KitsuneFang;
import Player.Player;
import game.exceptions.EnemyDeadException;
import util.Randomized;

import static util.Randomized.randomizeNumber;


public class KitsuneSorcerer extends Enemy {

    public KitsuneSorcerer() {
        super("Kitsune Hechicero", 25, 4, 3, 10);
    }

    @Override
    public void attack(Player player) throws EnemyDeadException {
        if (!isDead()) {

            double plainAttackProbability = 0.5;
            double runAwayProbability = 0.2;
            double stealGoldProbability = 0.3;
            double totalProbability = plainAttackProbability + runAwayProbability + stealGoldProbability;
            double ratio = Randomized.randomizeDouble(totalProbability);
            // plainAttackProbability = 50%, runAwayProbability = 20%, stealGoldProbability = 30%
            // plainAttackProbability + runAwayProbability + stealGoldProbability = 100%
            // ratio = 0.0 - 0.5 -> plainAttack, ratio = 0.51 - 0.8 -> stealGold, ratio = 0.81 - 1.0 -> runAway
            if (ratio <= plainAttackProbability) plainAttack(player);
            else if (ratio <= plainAttackProbability + stealGoldProbability) stealGold(player);
            else runAway();
        } else {
            throw new EnemyDeadException();
        }
    }
    @Override
    public void dropItem(Player player) {

        int ratio = Randomized.randomizeNumber(1, 100);
        player.getInventory().addItem(ratio > 50 ? new WoodenSword() : new KitsuneFang());
    }
    private void plainAttack(@NotNull Player player) {

        Interactive.printDialog(String.format("¡El Kitsune Hechizero ataca con %d daño!", getDamage()));
        player.takeDamage(getDamage());
    }

    public void runAway() {

        Interactive.printDialog("¡El Kitsune Hechicero huye!");
        this.setHealth(0);
    }

    public void stealGold(@NotNull Player player) {

        try {
            int minus = player.getGold() - 5;
            if (minus < 0)
                throw new ZeroException();
            player.setGold(minus);
            Interactive.printDialog("¡El Kitsune Hechicero roba 5 de oro!");
        } catch (ZeroException e) {
            player.setGold(0);
            Interactive.printDialog("¡La billetera del jugador está vacía!");
        }
    }
}
