package util;

import java.util.Random;

public class Randomized {

    private Randomized() {
        // Constructor privado para evitar instanciación
    }

    public static int randomizeNumber(int min, int max) {
        return new Random().nextInt(max - min + 1) + min;
    }
}