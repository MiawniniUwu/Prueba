package Player;

import Characters.BasicCharacter;
import Enemies.Enemy;
import Items.Armors.Armor;
import Items.Weapons.Weapon;
import game.exceptions.PlayerDeathException;
import util.Interactive;
import util.Randomized;

import javax.swing.*;
import java.io.Serializable;

public class Player extends BasicCharacter implements Serializable {

    protected int experience;
    protected int level;
    protected int str;
    protected int dex;
    protected int def;
    protected int intll;
    protected int luk;
    protected int cha;
    protected int agi;
    protected int ma;
    protected Weapon weapon;
    protected Armor armor;
    private int gold;
    private final Inventory inventory;

    public Player(String name) {
        super(name, 30, 10);
        experience = 0;
        level = 1;
        gold = 0;
        weapon = null;
        armor = null;
        randomizeStats(30);
        inventory = new Inventory();
    }
    public void randomizeStats(int maxPoints) {

        int stat = Randomized.randomizeNumber(1, 5);
        while (maxPoints > 0) {
            switch (stat) {
                case 1 -> {
                    if (str < (level * 5)) str++;
                    else maxPoints++;
                }
                case 2 -> {
                    if (def < (level * 5)) def++;
                    else maxPoints++;
                }
                case 3 -> cha++;
                case 4 -> dex++;
                case 5 -> luk++;
            }
            maxPoints--;
            stat = Randomized.randomizeNumber(1, 5);
        }
    }

    public void equipWeapon(Weapon weapon) {

        this.weapon = weapon;
    }

    public void equipArmor(Armor armor) {

        this.armor = armor;
    }

    public void revive() {

        hp = maxHp;
        mp = maxMp;
    }
    public void attack(@NotNull Enemy enemy) throws PlayerDeathException {

        if (!isDead()) {

            Interactive.printDialog(String.format("%s ataca con %d puntos de daño!", getName(), getDamage()));
            enemy.takeDamage(getDamage());
            if (enemy.isDead()) getRewards(enemy);
        } else {
            throw new PlayerDeathException();
        }
    }

    private void getRewards(@NotNull Enemy enemy) {

        gainExperience(enemy.getExperience());
        gainGold(enemy.getGold());
        enemy.dropItem(this);
    }

    public void attack(BasicCharacter enemy) {

        int damage = str + (int) (Math.random() * 5);
        JOptionPane.showMessageDialog(null,
                String.format("%s ataca con %d de daño!", name, damage));
    }

    public void flee() {

        JOptionPane.showMessageDialog(null, "¡Has huido!");
    }

    public void defend() {

        JOptionPane.showMessageDialog(null, "¡Te has defendido!");
    }

    @Override
    public void displayData() {

        String output = String.format("Name: %s\n", name);
        output += String.format("\tHP: %d/%d\n", hp, maxHp);
        output += String.format("\tMP: %d/%d\n", mp, maxMp);
        output += String.format("\tExperience: %d\n", experience);
        output += String.format("\tLevel: %d\n", level);
        output += String.format("\tStrength: %d\n", str);
        output += String.format("\tDexterity: %d\n", dex);
        output += String.format("\tDefense: %d\n", def);
        output += String.format("\tIntelligence: %d\n", intll);
        output += String.format("\tLuck: %d\n", luk);
        output += String.format("\tCharm: %d\n", cha);
        output += String.format("\tAgility: %d\n", agi);
        output += String.format("\tLMagic: %d\n", ma);
        JOptionPane.showMessageDialog(null, output);

        String message = String.format("""
						Nombre: %s
						Nivel: %d
						Experiencia: %s
						Salud: %s
						Mana: %s
						Fuerza: %s
						Defensa: %s
						Inteligencia: %d
						Destreza: %d
						Suerte: %d
						Oro: %d
						Arma: %s
						Armadura: %s""",
                getName(), level, getActualExperience(), getActualHp(), getActualMp(), getTotalAttack(),
                getTotalDefense(), intll, dex, luk, gold, getWeaponName(), getArmorName());
        Interactive.printDialog(message);
    }

    private String getActualHp() {

        return String.format("%d/%d", getHp(), getMaxHp());
    }

    private String getActualMp() {

        return String.format("%d/%d", getMp(), getMaxMp());
    }

    private String getActualExperience() {

        return String.format("%d/%d", experience, level * 20);
    }

    private String getTotalAttack() {

        return weapon != null ? String.format("%d (+ %d)", str, weapon.getAtk()) : String.valueOf(str);
    }

    private String getTotalDefense() {

        return armor != null ? String.format("%d (+ %d)", def, armor.getDef()) : String.valueOf(def);
    }

    public void attack(Enemy enemy) {

        System.out.println(enemy.getName() + " attacks for " + getDamage() + " damage!");
        enemy.takeDamage();
        if (enemy.isDead()) {

            gainExperience(enemy.getExperience());
            gainGold(enemy.getGold());
        }
    }

    public void gainExperience(int experience) {

        this.experience += experience;
        printExperience(experience);
        checkLevelUp();
    }
    private void checkLevelUp() {

        if (this.experience >= level * 20) {

            level++;
            maxHp += 5;
            maxMp += 3;
            hp = maxHp;
            mp = maxMp;
            randomizeStats(5);
            printLevelUp();
        }
    }

    public void gainGold(int gold) {

        this.gold += gold;
        printGold(gold);
    }
    public void printLevelUp() {

        Interactive.printDialog(String.format("¡Felicidades! Has subido al nivel %d!", level));
        displayData();
    }

    public int getDamage() {

        return weapon != null ? str + weapon.getAttack() : str;
    }

    public void takeDamage(int damage) {

        if (armor != null) {

            damage -= armor.getDefense();
            if (damage < 0) damage = 0;
        }
        super.takeDamage(damage);
        if (isDead()) printDeath();
    }

    private void printDeath() {
        Interactive.printDialog("¡Has muerto!");
    }
    public void printRun() {

        Interactive.printDialog("¡Has huido!");
    }
    public void printGold(int gold) {

        Interactive.printDialog(String.format("Has ganado %d monedas de oro!", gold));
    }

    public void printExperience(int experience) {

        Interactive.printDialog(String.format("Has ganado %d puntos de experiencia!", experience));
    }

    public void printHeal(int heal) {

        Interactive.printDialog(String.format("Has recuperado %d puntos de salud!", heal));
    }

    public void printEquipWeapon(@NotNull Weapon weapon) {

        Interactive.printDialog(String.format("Has equipado %s!", weapon.getName()));
    }

    public void printEquipArmor(@NotNull Armor armor) {

        Interactive.printDialog(String.format("Has equipado %s!", armor.getName()));
    }

    public String getWeaponName() {

        return weapon != null ? weapon.getName() : "None";
    }

    public String getArmorName() {

        return armor != null ? armor.getName() : "None";
    }

    public int getDamage() {

        return weapon != null ? str + weapon.getAtk() : str;
    }

    public void reduceGold(int i) {
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getStr() {
        return str;
    }

    public void setStr(int str) {
        this.str = str;
    }

    public int getDex() {
        return dex;
    }

    public void setDex(int dex) {
        this.dex = dex;
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public int getIntll() {
        return intll;
    }

    public void setIntll(int intll) {
        this.intll = intll;
    }

    public int getLuk() {
        return luk;
    }

    public void setLuk(int luk) {
        this.luk = luk;
    }

    public int getCha() {
        return cha;
    }

    public void setCha(int cha) {
        this.cha = cha;
    }

    public int getAgi() {
        return agi;
    }

    public void setAgi(int agi) {
        this.agi = agi;
    }

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public Armor getArmor() {
        return armor;
    }

    public void setArmor(Armor armor) {
        this.armor = armor;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public Inventory getInventory() {
        return inventory;
    }

}

